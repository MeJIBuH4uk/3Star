<footer>
	<p>Все права защищены &copy; <?php echo date(Y); ?></p>
	<p>Ссылки на СоцСети</p>
</footer>