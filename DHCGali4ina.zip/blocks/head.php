<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="css/style.css">
	<title><?=$title?></title>

	<script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<script>window.JQuery || document.write('<script src="js/jquery-3.2.1.min.js"><\/script>');</script>
</head>