<header>

	<a href="/" id="logo"><img src="/img/logo2.png" alt="logotype" title="На Главную"></a>
	
	<div>Название сайта</div>

	<form>
		<input type="text" name="search" placeholder="Поиск ..Находится на доработке...">
		<button type="submit">Поиск</button>
	</form>

	<br><p>Время работы: с 9:00 до 21:00 по Киеву</p><br>

	<p>Номер телефона: +38 066-027-66-52</p>

	<ul>
		<li><a href="#">Каталог</a></li>
		<li><a href="#">Обратная связь</a></li>
		<li><a href="#">О Нас</a></li>
	</ul>

</header>