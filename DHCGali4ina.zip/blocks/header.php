<header>

	<a href="/" id="logo"><img src="/img/logo2.png" alt="logotype" title="На Главную"></a>
	
	<div><img src="/img/fucking_star.png" alt="star"><img src="/img/fucking_star.png" alt="star"><img src="/img/fucking_star.png" alt="star"> 3Star <img src="/img/fucking_star.png" alt="star"><img src="/img/fucking_star.png" alt="star"><img src="/img/fucking_star.png" alt="star"></div>

	<form>
		<input type="text" name="search" placeholder="Поиск.. Находится на доработке..">
		<button type="button">Поиск</button>
	</form>

	<br><p>Время работы: с 9:00 до 21:00 по Киеву</p><br>

	<p>Номер телефона: +38 066-027-66-52</p>

	<ul>
		<li><a href="catalog.php">Каталог</a></li>
		<li><a href="feedback.php">Обратная связь</a></li>
		<li><a href="about.php">О Нас</a></li>
	</ul>

</header>