<?php

	require 'libs/rb.php';

	R::setup( 'mysql:host=mysql.hostinger.com.ua;dbname=u971386972_dhc', 'u971386972_poli', '123456' );
	// R::setup( 'mysql:host=localhost;dbname=phpsite_user', 'root', '' );

	session_start();

?>