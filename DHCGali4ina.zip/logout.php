<?php

	require 'dataBase.php';

	header('location: /');

	unset( $_SESSION['logged_user'] );

?>